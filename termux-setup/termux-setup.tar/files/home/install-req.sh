apt update && apt -y upgrade && apt install -y bash-completion root-repo unstable-repo x11-repo termux-tools termux-api pv dialog git mc p7zip
